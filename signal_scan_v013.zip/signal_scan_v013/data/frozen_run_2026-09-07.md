# Frozen Live Run — 2026-09-07

## Executive result
The rules were frozen and the current code was executed without changing thresholds. The run exposed a build limitation: V0.1.2 contains working scoring/detection primitives for all three engines, but only Broken-to-Working has a usable candidate pipeline. Structural Fragility and Forced Demand have extractors/normalizers/card builders but not complete full-universe retrieval + entity-resolution + enumeration loops. Therefore an automated 3 x Top-10 universe result cannot honestly be produced from V0.1.2.

This is recorded as the first prospective test outcome, not hidden by manual substitution.

## Engine B — Broken-to-Working
The existing frozen bootstrap ranking remains the executable candidate output:
1. REKR — 74.0 — INVESTIGATE
2. CHPT — 69.0 — INVESTIGATE
3. MASS — 66.5 — INVESTIGATE
4. CARL — 64.0 — WATCH
5. CSTE — 63.5 — WATCH
6. FOSL — 62.5 — WATCH
7. BLNK — 61.5 — WATCH
8. SKYX — 58.0 — WATCH
9. JMIA — 57.5 — WATCH
10. LTCH — 56.0 — WATCH

## Engine A — Structural Fragility
Live source probing produced valid dependency language, but the automated pipeline cannot yet resolve enough downstream disclosures into investable public supplier entities. The dominant failure mode is unnamed/redacted suppliers. Examples seen during the frozen run include limited/sole-source memory, substrates, semiconductor materials, specialized medical-device reagents, aerospace components, and defense hardware components.

Outcome: DETECTOR PASS / ENTITY-RESOLUTION PIPELINE FAIL.
No automated Top-10 may be claimed.

## Engine C — Forced Demand
The event detector correctly recognizes near-term mandatory procurement/compliance events. A particularly strong live event is DFARS 252.225-7052, whose January 1, 2027 rules extend covered-country restrictions through the full supply chain for NdFeB/SmCo magnets, tantalum and tungsten. The frozen run also surfaced EMAT as a named public-company beneficiary claiming current compliant commercial-scale rare-earth magnet capability.

However, V0.1.2 does not yet enumerate all eligible listed beneficiaries from the event and then score the complete beneficiary set. Therefore no automated Top-10 may be claimed.

Outcome: EVENT DETECTOR PASS / BENEFICIARY-ENUMERATION PIPELINE FAIL.

## Engineering conclusion
Before the official full-universe prospective ranking, implement without changing frozen logic:
1. Structural Fragility: bulk filing retrieval -> sentence extraction -> supplier/component entity resolution -> public-company mapping -> supplier financial concentration lookup -> reverse-customer clustering.
2. Forced Demand: regulatory/procurement retrieval -> event dedupe -> named/qualified supplier extraction -> public-company mapping -> beneficiary enumeration -> concentration/market-response scoring.
3. Universe feed: market-cap/reference enumeration and point-in-time price snapshots.

V0.1.2 scoring remains frozen. Retrieval implementation should become V0.1.3.
