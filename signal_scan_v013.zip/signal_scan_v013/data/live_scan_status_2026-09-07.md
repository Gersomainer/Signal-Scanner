# Signal Scan — bootstrap live pass
Freeze date: 2026-09-07

This is NOT yet the official full-universe Top-10. It is the first live candidate pass used to validate candidate-generation and scoring behavior while the full Massive-backed universe enumeration is unfinished.

## What changed in code
- Engine-specific scoring weights for Broken-to-Working.
- 'Concentration' for Broken-to-Working is interpreted as operating-inflection breadth across consolidated economics, not product revenue concentration.
- Added Forced-Demand phrase detector skeleton.
- Added market-response helper so rerating is measured after the signal date.
- Added pipeline module for turning raw CompanyFacts into a scored SignalCard.
- Test suite expanded from 3 to 5 tests; all pass.

## Preliminary Broken-to-Working queue
1. REKR — INVESTIGATE — strongest raw inflection, but liquidity/refinancing is a gating risk.
2. CHPT — INVESTIGATE — very strong Q2 FY27 improvement, but the stock repriced immediately after earnings.
3. MASS — INVESTIGATE — strong growth + loss narrowing + excellent cash, but already substantially rerated.
4. CARL — WATCH — excellent growth/margin profile, but not deeply distressed enough to create ROOT-style convexity.
5. CSTE — WATCH — restructuring improvement, partly repriced and tariff-sensitive.
6. FOSL — WATCH — real turnaround and positive operating income, but rerating already meaningful.
7. BLNK — WATCH — breakeven setup worth monitoring; capital structure needs primary-source DD.
8. SKYX — WATCH — mixed: cash burn improves, but YoY EBITDA is not yet confirming cleanly.
9. JMIA — WATCH — operating leverage improving; capital raise reduces convexity.
10. LTCH/DOOR — WATCH — interesting operating improvement but OTC liquidity and legacy regulatory issues penalize it heavily.

## Current gating item
A true full-universe scan needs a complete US-listed ticker/reference universe with market caps and historical prices. The code supports Massive for that role, but this runtime has no MASSIVE_API_KEY. Until that key is supplied in an execution environment, web-search bootstrapping is useful for validating logic but cannot honestly be called exhaustive.
