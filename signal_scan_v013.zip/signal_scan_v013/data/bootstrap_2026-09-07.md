# Bootstrap live pass — 2026-09-07

This is NOT the frozen Top-10 production scan. It records candidates surfaced while validating V0.1 keyword/filing logic before full-universe market-data ingestion is available.

## REKR — Rekor Systems — Broken-to-Working
- Q2 2026 revenue $12.7m, +23% sequentially.
- Adjusted gross margin 56% vs 50% YoY.
- Adjusted EBITDA loss narrowed 79% YoY to $1.2m.
- Six-month operating cash use improved 61% YoY.
- Cash ~$9.8m at 2026-06-30; quarterly operating burn reported ~$2.4m.
- 137.636m shares outstanding at 2026-08-12.
- 2026-09-04 close ~$0.54; market cap ~$73.8m; market cap down ~47% YoY.
- Major caution: limited runway / refinancing risk can overwhelm the operating inflection. This is an INVESTIGATE candidate, not a buy signal.

## Methodology issue exposed
For Broken-to-Working candidates, "economic concentration" cannot simply equal product/segment revenue concentration. The score should measure how directly the improving KPI maps to consolidated equity economics. This needs an engine-specific concentration rubric before the first frozen Top-10 scan.
