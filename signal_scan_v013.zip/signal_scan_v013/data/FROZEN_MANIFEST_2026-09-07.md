# Signal Scan V0.1.2 — Frozen Manifest

Freeze date: 2026-09-07
Status: RULES FROZEN

The following are frozen for the prospective test:
- Discovery universe preference: US-listed operating companies, $30M-$5B market cap
- Engines: Structural Fragility, Broken-to-Working, Forced Demand
- Engine thresholds and pattern dictionaries
- Common 100-point scoring framework and engine-specific weights
- Classification thresholds
- Kill-switch philosophy

No scoring thresholds or phrase patterns may be changed in response to names surfaced by the 2026-09-07 run. Engineering changes that only add retrieval/enumeration plumbing are allowed, but must increment the implementation version while preserving this frozen scoring manifest.
