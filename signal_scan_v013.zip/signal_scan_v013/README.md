# Signal Scan V0.1

Purpose: detect listed companies near a nonlinear change in earnings/equity value before the market fully reprices it.

## V0.1 scope
- US-listed operating companies
- discovery market-cap preference: $30M-$5B
- engines: Structural Fragility, Broken-to-Working, Forced Demand (skeleton)
- common 100-point scoring layer
- frozen-signal database for prospective testing

## Data
- SEC EDGAR: free, no API key. Set `SEC_USER_AGENT` to a descriptive identity/contact.
- Massive: set `MASSIVE_API_KEY`. Free tier is sufficient for the initial market/reference layer.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export SEC_USER_AGENT='Your Name your@email.com'
export MASSIVE_API_KEY='...'
streamlit run app.py
```

## Current status
V0.1 plumbing + scoring + SEC/Massive clients + first two engine primitives are implemented. Full-universe candidate generation and Forced-Demand ingestion are the next implementation increment.

## Design rule
A high Signal Score means "investigate now", not "buy". Primary evidence and kill switches remain mandatory before investment decisions.

## V0.1.1 update — 2026-09-07
- Added engine-specific weights: Broken-to-Working now emphasizes nonlinearity and survival more heavily.
- Added Forced-Demand text detector skeleton.
- Added market-response utilities and candidate pipeline.
- Expanded tests to 5/5 passing.
- Added `data/bootstrap_candidates_2026-09-07.csv` and `data/live_scan_status_2026-09-07.md`.

Important: the bootstrap candidate list is **not** the official exhaustive Top-10. Full-universe enumeration requires the market/reference feed (Massive key in the runtime). The bootstrap is being used to validate scoring behavior first.

## V0.1.2 update — engine completion before live universe scan
Per design decision, live-universe ranking is paused until all three engines exist.

### Structural Fragility / Concentration
- Expanded dependency language extraction: sole/single source, limited supplier base, no alternative, qualification friction, allocation/lead-time constraints, and capacity commitments.
- Added `DependencyObservation` and `FragilityCluster` models.
- Added conservative supplier-name extraction from downstream disclosure context.
- Added reverse-dependency clustering by supplier and independent-customer confirmation boost.
- Added Structural Fragility Signal Card builder; economic concentration and nonlinear sensitivity remain second-stage supplier DD fields, not guessed from text.

### Forced Demand
- Added event model with publication/effective dates, final-rule state, supplier-pool size, and named beneficiaries.
- Added deadline proximity logic (<=24 months), mandatory/replacement/certification/local-content/procurement patterns, and constrained-supplier scoring.
- Added generic regulatory normalizer.
- Added SAM.gov and TED procurement normalizers. Retrieval is intentionally source-separated from scoring.
- Added Forced Demand Signal Card builder.

### Validation
- Test suite: 7/7 passing.
- No live-universe Top-10 has been run after these changes. This prevents tuning the engines to names surfaced during development.

### Source architecture
- SEC `data.sec.gov`: submissions/XBRL, no authentication; bulk archives are preferred for large-scale ingestion.
- SAM.gov: public contract opportunities include sole-source notices; use official data services/API rather than scraping.
- TED Search API: published EU procurement notices, anonymous access, pagination/iteration support.

## V0.1.3 retrieval/entity-resolution increment

V0.1.3 leaves the V0.1.2 scoring rules frozen and adds plumbing only:

- SEC listed-company universe retrieval (`universe.py`)
- Massive market-cap enrichment/filtering for the $30M-$5B discovery universe
- SEC recent-filing URL construction and HTML-to-text extraction (`filings.py`)
- conservative public-company entity resolver (`entity_resolution.py`)
- Engine A downstream filing scan -> reverse supplier clusters -> listed ticker resolution (`structural_pipeline.py`)
- Federal Register rule ingestion and TED adapter (`forced_sources.py`)
- Engine C named-beneficiary/vendor extraction -> listed ticker resolution (`beneficiary_resolution.py`)
- reproducible CLI runner (`python -m signal_scan.live_runner`)

### Run

```bash
export SEC_USER_AGENT="SignalScan your-email@example.com"
export MASSIVE_API_KEY="..."   # omit only with --skip-market-cap
python -m signal_scan.live_runner --out data/live_v013
```

For a connectivity/plumbing smoke test without Massive:

```bash
python -m signal_scan.live_runner --skip-market-cap --structural-limit 25
```

The runner writes raw Engine A and C CSVs plus a manifest. These are candidate-generation outputs only; V0.1.2's frozen common scorer is applied afterward.

### Current environment note

The packaged code passes its offline unit tests. The build container used to create V0.1.3 has outbound DNS disabled, so live SEC/Federal Register endpoint execution cannot be verified inside that container. The runner is intentionally kept separate from scoring so the same frozen code can be executed unchanged in a networked runtime.
