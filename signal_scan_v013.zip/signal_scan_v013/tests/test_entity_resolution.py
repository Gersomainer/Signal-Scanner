from signal_scan.entity_resolution import PublicCompanyResolver
from signal_scan.models import Company

def test_exact_company_resolution():
    r = PublicCompanyResolver([Company('AXTI','AXT, Inc.'), Company('PFE','Pfizer Inc.')])
    x = r.resolve('Pfizer, Inc.')
    assert x.company and x.company.ticker == 'PFE'
    assert x.confidence == 1.0

def test_unresolved_generic_name():
    r = PublicCompanyResolver([Company('PFE','Pfizer Inc.')])
    assert r.resolve('Global Materials Supplier').company is None
