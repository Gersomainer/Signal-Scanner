from signal_scan.fragility import DependencyObservation, cluster_by_supplier

def test_repeated_customer_dependency_boosts_cluster():
    obs = [
        DependencyObservation("A", "2026-01-01", "sole_source", "x", supplier="Tiny Supplier Inc"),
        DependencyObservation("B", "2026-02-01", "qualification", "x", supplier="Tiny Supplier Inc"),
        DependencyObservation("C", "2026-03-01", "limited_suppliers", "x", supplier="Tiny Supplier Inc"),
    ]
    c = cluster_by_supplier(obs)[0]
    assert c.independent_customers == 3
    assert c.engine_score == 5
