from signal_scan.forced_demand import evaluate_text

def test_forced_demand_detection():
    r = evaluate_text("All installed units must be replaced by 2028. Only qualified suppliers may bid.", final_rule=True, near_term=True, constrained_supplier_pool=True)
    assert r.qualifies
    assert r.engine_score >= 4
