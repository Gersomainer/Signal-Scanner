from signal_scan.models import CandidateMetrics, Company, SignalCard
from signal_scan.scoring import finalize

def test_btw_survival_has_more_weight():
    m = CandidateMetrics(concentration=3, nonlinearity=4, evidence=4, market_response=4, moat=2, survival=5, dilution=4, insider=2.5)
    c = SignalCard(Company("X","X"), "Broken-to-Working", "x", "2026-09-07", 4, m)
    out = finalize(c)
    assert out.total_score > 60
