from signal_scan.beneficiary_resolution import resolve_event_beneficiaries
from signal_scan.forced_demand import ForcedDemandEvent
from signal_scan.models import Company

def test_named_beneficiary_maps_to_public_company():
    e=ForcedDemandEvent(title='Rule',publication_date='2026-01-01',source_type='x',text='Manufacturers must comply.',effective_date='2026-12-01',final_rule=True,named_beneficiaries=['Pfizer Inc.'])
    out=resolve_event_beneficiaries([e],[Company('PFE','Pfizer Inc.')])
    assert out and out[0].ticker == 'PFE'
