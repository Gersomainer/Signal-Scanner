from signal_scan.fragility import extract_fragility_hits, score_fragility

def test_fragility():
    t="We depend on a limited number of suppliers and qualification process for alternatives is lengthy."
    h=extract_fragility_hits(t)
    assert len(h)>=2
    assert score_fragility(h)>=4
