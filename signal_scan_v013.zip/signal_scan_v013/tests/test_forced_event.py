from signal_scan.forced_demand import ForcedDemandEvent, evaluate_event

def test_final_near_term_mandate_constrained_pool_scores_high():
    e = ForcedDemandEvent(
        title="Mandatory retrofit",
        publication_date="2026-01-01",
        effective_date="2027-01-01",
        source_type="Regulator",
        text="A mandatory retrofit is required and devices must comply by the deadline.",
        final_rule=True,
        supplier_pool_size=2,
        named_beneficiaries=["Vendor A"],
    )
    r = evaluate_event(e)
    assert r.qualifies
    assert r.engine_score >= 4.5
