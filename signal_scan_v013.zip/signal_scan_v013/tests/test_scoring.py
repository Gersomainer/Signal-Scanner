from signal_scan.models import CandidateMetrics
from signal_scan.scoring import score, classify

def test_score_extreme():
    m=CandidateMetrics(5,5,5,5,5,5,5,5)
    assert score(m)==100
    assert classify(100)=="EXCEPTIONAL"

def test_neutral_insider_not_zero():
    m=CandidateMetrics(insider=2.5)
    assert score(m)==2.5
