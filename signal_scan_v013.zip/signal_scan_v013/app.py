import streamlit as st
import pandas as pd
from signal_scan.storage import Store

st.set_page_config(page_title="Signal Scan", layout="wide")
st.title("Signal Scan V0.1")
st.caption("Early-warning system for nonlinear equity re-rating candidates")

try:
    db = Store("signal_scan.db")
    df = pd.read_sql_query("SELECT freeze_date,ticker,engine,total_score,classification,payload_json FROM frozen_signals ORDER BY total_score DESC", db.conn)
    st.dataframe(df.drop(columns=["payload_json"]), use_container_width=True)
except Exception as e:
    st.info(f"No frozen scan yet: {e}")
