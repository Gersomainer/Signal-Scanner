from dataclasses import dataclass, field
import os

@dataclass(frozen=True)
class Settings:
    min_market_cap: float = 30_000_000
    max_market_cap: float = 5_000_000_000
    sec_user_agent: str = os.getenv("SEC_USER_AGENT", "SignalScan research contact@example.com")
    massive_api_key: str | None = os.getenv("MASSIVE_API_KEY")
    frozen_date: str = os.getenv("SIGNAL_SCAN_DATE", "2026-09-07")
    allowed_forms: tuple[str, ...] = ("10-K", "10-Q", "8-K", "20-F", "6-K", "S-1", "DEF 14A")

SETTINGS = Settings()
