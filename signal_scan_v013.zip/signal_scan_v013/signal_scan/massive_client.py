from __future__ import annotations
import requests
from .config import SETTINGS

class MassiveClient:
    BASE = "https://api.massive.com"
    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or SETTINGS.massive_api_key
        if not self.api_key:
            raise RuntimeError("Set MASSIVE_API_KEY in the environment.")
        self.session = requests.Session()

    def _get(self, path: str, params: dict | None = None):
        params = dict(params or {})
        params["apiKey"] = self.api_key
        r = self.session.get(self.BASE + path, params=params, timeout=30)
        r.raise_for_status()
        return r.json()

    def ticker_details(self, ticker: str, date: str | None = None):
        params = {"date": date} if date else None
        return self._get(f"/v3/reference/tickers/{ticker}", params)

    def daily_bars(self, ticker: str, start: str, end: str):
        return self._get(f"/v2/aggs/ticker/{ticker}/range/1/day/{start}/{end}", {"adjusted": "true", "sort": "asc", "limit": 50000})
