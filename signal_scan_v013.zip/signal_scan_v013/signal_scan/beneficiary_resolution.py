from __future__ import annotations
import re
from dataclasses import dataclass
from .entity_resolution import PublicCompanyResolver
from .forced_demand import ForcedDemandEvent, evaluate_event

VENDOR_PATTERNS = [
    re.compile(r"(?:awarded to|awardee|contractor|supplier|vendor|manufacturer|provided by)\s+([A-Z][A-Za-z0-9&.,'()\- ]{2,80}?)(?=,|;|\.|\band\b)", re.I),
]

@dataclass
class BeneficiaryCandidate:
    event_title: str
    beneficiary_name: str
    ticker: str | None
    company_name: str | None
    engine_score: float
    resolution_confidence: float
    source_url: str | None
    status: str


def extract_beneficiary_names(event: ForcedDemandEvent) -> list[str]:
    names = list(event.named_beneficiaries)
    for pat in VENDOR_PATTERNS:
        for m in pat.finditer(event.text):
            names.append(re.sub(r'\s+', ' ', m.group(1)).strip(' ,.;'))
    return list(dict.fromkeys(n for n in names if n))


def resolve_event_beneficiaries(events: list[ForcedDemandEvent], public_universe):
    resolver = PublicCompanyResolver(public_universe)
    out = []
    for event in events:
        er = evaluate_event(event)
        if not er.qualifies:
            continue
        for name in extract_beneficiary_names(event):
            res = resolver.resolve(name)
            out.append(BeneficiaryCandidate(
                event_title=event.title,
                beneficiary_name=name,
                ticker=res.company.ticker if res.company else None,
                company_name=res.company.name if res.company else None,
                engine_score=er.engine_score,
                resolution_confidence=res.confidence,
                source_url=event.source_url,
                status='RESOLVED' if res.company else 'UNRESOLVED',
            ))
    return sorted(out, key=lambda x: (x.status == 'RESOLVED', x.engine_score, x.resolution_confidence), reverse=True)
