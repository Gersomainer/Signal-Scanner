from pathlib import Path
import pandas as pd

def write_html(cards, path: str):
    rows = [c.to_dict() if hasattr(c, "to_dict") else c for c in cards]
    df = pd.json_normalize(rows)
    keep = [c for c in ["ticker","company_name","engine","engine_score","total_score","classification","signal","key_risk"] if c in df.columns]
    html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>Signal Scan</title>"
    html += "<style>body{font-family:-apple-system,Arial;margin:24px}table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #ddd;padding:10px;text-align:left}th{position:sticky;top:0;background:white}</style></head><body>"
    html += f"<h1>Signal Scan V0.1</h1><p>{len(df)} frozen candidates</p>" + df[keep].sort_values("total_score", ascending=False).to_html(index=False, escape=True) + "</body></html>"
    Path(path).write_text(html, encoding="utf-8")
