from __future__ import annotations
from collections import defaultdict

# Common tags; companies can use alternatives, so extraction remains intentionally conservative.
TAG_ALIASES = {
    "revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet"],
    "gross_profit": ["GrossProfit"],
    "operating_income": ["OperatingIncomeLoss"],
    "net_income": ["NetIncomeLoss", "ProfitLoss"],
    "cash": ["CashAndCashEquivalentsAtCarryingValue", "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"],
    "debt": ["LongTermDebtCurrent", "LongTermDebtNoncurrent", "ShortTermBorrowings"],
    "operating_cf": ["NetCashProvidedByUsedInOperatingActivities"],
    "shares": ["CommonStockSharesOutstanding"],
}

def _facts(companyfacts: dict, tag: str):
    for taxonomy in ("us-gaap", "ifrs-full"):
        obj = companyfacts.get("facts", {}).get(taxonomy, {}).get(tag)
        if obj:
            for unit, rows in obj.get("units", {}).items():
                for row in rows:
                    yield row

def latest_filed_series(companyfacts: dict, metric: str, forms=("10-Q", "10-K", "20-F", "6-K")):
    rows = []
    for tag in TAG_ALIASES.get(metric, []):
        for row in _facts(companyfacts, tag):
            if row.get("form") in forms and row.get("filed") and row.get("val") is not None:
                rows.append({**row, "tag": tag})
    rows.sort(key=lambda x: (x.get("end", ""), x.get("filed", "")))
    return rows

def quarterly_values(companyfacts: dict, metric: str):
    rows = latest_filed_series(companyfacts, metric)
    # Prefer explicit quarter facts (FP=Q1/Q2/Q3 or form 10-Q) and dedupe end date.
    by_end = {}
    for r in rows:
        if r.get("form") == "10-Q" or r.get("fp") in {"Q1", "Q2", "Q3"}:
            by_end[r.get("end")] = r
    return [by_end[k] for k in sorted(by_end) if k]
