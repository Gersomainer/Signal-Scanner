from __future__ import annotations
import re
import requests
from bs4 import BeautifulSoup
from .config import SETTINGS


def recent_filing_records(submissions: dict, forms: tuple[str, ...] | None = None, limit: int = 8):
    forms = forms or SETTINGS.allowed_forms
    recent = (submissions.get('filings') or {}).get('recent') or {}
    n = len(recent.get('accessionNumber') or [])
    rows = []
    for i in range(n):
        form = recent.get('form', [''] * n)[i]
        if form not in forms:
            continue
        rows.append({
            'accession': recent['accessionNumber'][i],
            'filing_date': recent.get('filingDate', [''] * n)[i],
            'form': form,
            'primary_document': recent.get('primaryDocument', [''] * n)[i],
        })
        if len(rows) >= limit:
            break
    return rows


def filing_url(cik: str | int, accession: str, primary_document: str) -> str:
    cik_num = str(int(str(cik).replace('CIK','')))
    acc = accession.replace('-', '')
    return f'https://www.sec.gov/Archives/edgar/data/{cik_num}/{acc}/{primary_document}'


def fetch_filing_text(url: str, user_agent: str | None = None) -> str:
    r = requests.get(url, headers={'User-Agent': user_agent or SETTINGS.sec_user_agent}, timeout=40)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    for tag in soup(['script','style']):
        tag.decompose()
    text = soup.get_text(' ', strip=True)
    return re.sub(r'\s+', ' ', text)
