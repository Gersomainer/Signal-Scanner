import sqlite3, json
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS frozen_signals (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 freeze_date TEXT NOT NULL,
 ticker TEXT NOT NULL,
 engine TEXT NOT NULL,
 total_score REAL NOT NULL,
 classification TEXT NOT NULL,
 payload_json TEXT NOT NULL,
 UNIQUE(freeze_date, ticker, engine)
);
"""

class Store:
    def __init__(self, path="signal_scan.db"):
        self.path = Path(path)
        self.conn = sqlite3.connect(self.path)
        self.conn.executescript(SCHEMA)

    def freeze(self, freeze_date: str, card):
        payload = card.to_dict() if hasattr(card, "to_dict") else card
        self.conn.execute("""INSERT OR REPLACE INTO frozen_signals
        (freeze_date,ticker,engine,total_score,classification,payload_json)
        VALUES(?,?,?,?,?,?)""", (freeze_date, payload["ticker"], payload["engine"], payload["total_score"], payload["classification"], json.dumps(payload, default=str)))
        self.conn.commit()
