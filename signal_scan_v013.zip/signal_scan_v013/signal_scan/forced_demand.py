from __future__ import annotations
import re
from dataclasses import dataclass, field
from datetime import date, datetime

PATTERNS = {
    "mandatory": r"\b(mandatory|required by law|shall comply|must comply|must be replaced|mandatory retrofit|required to replace|required to install)\b",
    "deadline": r"\b(effective (?:on|from)|compliance deadline|no later than|phase[- ]out|sunset|deadline)\b",
    "certification": r"\b(certified|approved vendor|approved supplier|type approval|qualification requirement|qualified product(?:s)? list)\b",
    "procurement": r"\b(sole source|only responsible source|brand name only|source approval|qualified source|limited sources justification)\b",
    "local_content": r"\b(local content|domestic content|made in america|buy america|country of origin requirement)\b",
    "replacement": r"\b(retrofit|replacement program|replace existing|upgrade existing|modernization mandate)\b",
}

@dataclass
class ForcedDemandEvent:
    title: str
    publication_date: str
    source_type: str
    text: str
    source_url: str | None = None
    effective_date: str | None = None
    final_rule: bool = False
    supplier_pool_size: int | None = None
    named_beneficiaries: list[str] = field(default_factory=list)

@dataclass
class ForcedDemandResult:
    qualifies: bool
    engine_score: float
    hits: list[dict]
    near_term: bool = False
    reasons: list[str] = field(default_factory=list)


def extract_hits(text: str):
    hits = []
    for label, pattern in PATTERNS.items():
        for m in re.finditer(pattern, text, flags=re.I):
            start, end = max(0, m.start()-220), min(len(text), m.end()+320)
            hits.append({"type": label, "match": m.group(0), "context": text[start:end].replace("\n", " ")})
    return hits


def _parse_date(value: str | None):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value[:10]).date()
    except ValueError:
        return None


def is_near_term(publication_date: str, effective_date: str | None, months: int = 24) -> bool:
    pub, eff = _parse_date(publication_date), _parse_date(effective_date)
    if not pub or not eff or eff < pub:
        return False
    return (eff - pub).days <= int(months * 30.44)


def score_hits(hits: list[dict], final_rule: bool = False, near_term: bool = False,
               constrained_supplier_pool: bool = False, named_beneficiary: bool = False):
    types = {h["type"] for h in hits}
    score = 0.0
    if "mandatory" in types:
        score = 2.5
    elif "procurement" in types:
        score = 2.25
    elif types & {"deadline", "replacement", "local_content", "certification"}:
        score = 1.5
    if final_rule:
        score += 0.75
    if near_term:
        score += 0.75
    if constrained_supplier_pool:
        score += 0.75
    if named_beneficiary:
        score += 0.5
    return min(5.0, round(score, 2))


def evaluate_event(event: ForcedDemandEvent):
    hits = extract_hits(event.text)
    near = is_near_term(event.publication_date, event.effective_date)
    constrained = event.supplier_pool_size is not None and event.supplier_pool_size <= 3
    score = score_hits(
        hits,
        final_rule=event.final_rule,
        near_term=near,
        constrained_supplier_pool=constrained,
        named_beneficiary=bool(event.named_beneficiaries),
    )
    reasons = []
    if event.final_rule: reasons.append("final/issued rule or procurement action")
    if near: reasons.append("implementation within 24 months")
    if constrained: reasons.append(f"supplier pool <= {event.supplier_pool_size}")
    if event.named_beneficiaries: reasons.append("named beneficiary/vendor")
    reasons.extend(sorted({h["type"] for h in hits}))
    return ForcedDemandResult(score >= 2.5, score, hits, near, reasons)


def evaluate_text(text: str, **kwargs):
    # Backward-compatible primitive for tests/manual text checks.
    hits = extract_hits(text)
    score = score_hits(hits, **kwargs)
    return ForcedDemandResult(score >= 2.5, score, hits)
