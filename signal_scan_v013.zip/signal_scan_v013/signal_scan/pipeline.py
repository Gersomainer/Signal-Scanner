from __future__ import annotations
from dataclasses import dataclass
from .broken_to_working import evaluate_companyfacts
from .models import Company, CandidateMetrics, SignalCard
from .scoring import finalize

@dataclass
class PipelineInput:
    company: Company
    companyfacts: dict
    drawdown: float | None = None
    evidence_score: float = 3.0
    market_response_score: float = 3.0
    survival_score: float = 2.5
    dilution_score: float = 2.5
    moat_score: float = 2.0
    insider_score: float = 2.5


def broken_to_working_card(inp: PipelineInput, freeze_date: str):
    result = evaluate_companyfacts(inp.companyfacts)
    if not result.qualifies:
        return None
    # Breadth proxy: current primitive counts independent improving consolidated metrics.
    breadth = min(5.0, 1.5 + 0.75 * len(result.reasons))
    # Nonlinearity rises with engine score; later versions will model distance-to-breakeven explicitly.
    nonlinear = min(5.0, 1.0 + 0.8 * result.engine_score)
    # Drawdown gate is a discovery condition for this engine; don't over-score if not distressed.
    market_resp = inp.market_response_score
    if inp.drawdown is not None and inp.drawdown > -0.70:
        market_resp = min(market_resp, 2.0)
    card = SignalCard(
        company=inp.company,
        engine="Broken-to-Working",
        signal="; ".join(result.reasons),
        first_detected_date=freeze_date,
        engine_score=result.engine_score,
        metrics=CandidateMetrics(
            concentration=breadth,
            nonlinearity=nonlinear,
            evidence=inp.evidence_score,
            market_response=market_resp,
            moat=inp.moat_score,
            survival=inp.survival_score,
            dilution=inp.dilution_score,
            insider=inp.insider_score,
        ),
        key_risk="Turnaround may fail before operating leverage reaches breakeven.",
        evidence_summary=str(result.metrics),
        discovery_state="Known + hated" if market_resp >= 4 else "Unknown",
    )
    return finalize(card)
