from __future__ import annotations
import re
from dataclasses import dataclass, field
from collections import defaultdict

PHRASES = {
    "sole_source": r"\bsole[- ]source(?:d)?\b|\bsingle[- ]source(?:d)?\b|\bonly qualified supplier\b|\bonly supplier\b",
    "limited_suppliers": r"\blimited (?:number of |supplier base|number of suppliers|sources?)\b|\bfew qualified suppliers\b|\bsmall number of suppliers\b",
    "no_alternative": r"\bno readily available alternative\b|\bno alternative source\b|\bno readily available substitute\b",
    "qualification": r"\blengthy qualification\b|\bqualification (?:process|period|cycle)\b|\bqualified supplier\b|\bqualify (?:an |a )?alternative supplier\b",
    "allocation": r"\bon allocation\b|\bcapacity constrained\b|\bextended lead time\b|\blong lead time\b|\bsupply constrained\b",
    "commitment": r"\bcapacity reservation\b|\bminimum purchase commitment\b|\btake[- ]or[- ]pay\b|\bcustomer[- ]funded (?:capacity|tooling)\b",
}

# Extract named counterparties conservatively from the immediate dependency sentence.
SUPPLIER_PATTERNS = [
    re.compile(r"(?:from|by|supplier(?:s)?(?: include| are| is)?|source(?:d)? from)\s+([A-Z][A-Za-z0-9&.,'()\- ]{2,80}?)(?=,|;|\.|\band\b|\bwhich\b|\bwho\b)", re.I),
    re.compile(r"([A-Z][A-Za-z0-9&.,'()\- ]{2,80}?)\s+(?:is|was|remains)\s+(?:our|the)\s+(?:sole|single|only qualified)\s+supplier", re.I),
]

@dataclass
class DependencyObservation:
    customer: str
    filing_date: str
    dependency_type: str
    context: str
    component: str | None = None
    supplier: str | None = None
    source_url: str | None = None

@dataclass
class FragilityCluster:
    key: str
    observations: list[DependencyObservation] = field(default_factory=list)
    independent_customers: int = 0
    engine_score: float = 0.0


def extract_fragility_hits(text: str):
    hits = []
    for label, pattern in PHRASES.items():
        for m in re.finditer(pattern, text, flags=re.I):
            start, end = max(0, m.start()-220), min(len(text), m.end()+320)
            context = text[start:end].replace("\n", " ")
            hits.append({"type": label, "match": m.group(0), "context": context})
    return hits


def extract_supplier_names(context: str) -> list[str]:
    names = []
    for pat in SUPPLIER_PATTERNS:
        for m in pat.finditer(context):
            name = re.sub(r"\s+", " ", m.group(1)).strip(" ,.;")
            # Reject sentence fragments and generic nouns.
            if 2 <= len(name.split()) <= 10 and not re.search(r"\b(material|component|product|wafer|supplier|source|company)\b$", name, re.I):
                names.append(name)
    return list(dict.fromkeys(names))


def score_fragility(hits: list[dict], independent_customers: int = 1):
    types = {h["type"] for h in hits}
    score = 0.0
    if "sole_source" in types:
        score = 4.5
    elif {"limited_suppliers", "qualification"} <= types:
        score = 4.0
    elif "no_alternative" in types and ("qualification" in types or "limited_suppliers" in types):
        score = 4.0
    elif "limited_suppliers" in types or "no_alternative" in types:
        score = 3.0
    elif "qualification" in types or "allocation" in types or "commitment" in types:
        score = 2.0
    if independent_customers >= 3:
        score += 1.0
    elif independent_customers == 2:
        score += 0.5
    return min(5.0, score)


def build_dependency_observations(customer: str, filing_date: str, text: str, source_url: str | None = None):
    observations = []
    for hit in extract_fragility_hits(text):
        suppliers = extract_supplier_names(hit["context"]) or [None]
        for supplier in suppliers:
            observations.append(DependencyObservation(
                customer=customer,
                filing_date=filing_date,
                dependency_type=hit["type"],
                context=hit["context"],
                supplier=supplier,
                source_url=source_url,
            ))
    return observations


def cluster_by_supplier(observations: list[DependencyObservation]) -> list[FragilityCluster]:
    grouped = defaultdict(list)
    for obs in observations:
        if obs.supplier:
            grouped[obs.supplier.lower()].append(obs)
    clusters = []
    for key, obs in grouped.items():
        customers = len({o.customer.lower() for o in obs})
        hits = [{"type": o.dependency_type} for o in obs]
        clusters.append(FragilityCluster(
            key=obs[0].supplier or key,
            observations=obs,
            independent_customers=customers,
            engine_score=score_fragility(hits, customers),
        ))
    return sorted(clusters, key=lambda c: (c.engine_score, c.independent_customers, len(c.observations)), reverse=True)
