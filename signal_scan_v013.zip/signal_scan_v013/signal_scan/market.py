from __future__ import annotations
from datetime import datetime


def max_drawdown_from_high(bars: list[dict]):
    closes = [b.get("c") for b in bars if b.get("c") is not None]
    if not closes: return None
    high = max(closes)
    last = closes[-1]
    if high == 0: return None
    return (last / high) - 1.0


def return_since(bars: list[dict], start_index: int = 0):
    closes = [b.get("c") for b in bars if b.get("c") is not None]
    if len(closes) < 2: return None
    start = closes[max(0, min(start_index, len(closes)-1))]
    return None if start == 0 else closes[-1] / start - 1.0


def market_response_score(change_since_signal: float | None, known_hated: bool = False, reset: bool = False):
    if known_hated and (change_since_signal is None or change_since_signal < 0.5): return 5.0
    if reset: return 4.0
    if change_since_signal is None: return 2.5
    if change_since_signal <= 0: return 5.0
    if change_since_signal < 0.5: return 4.0
    if change_since_signal < 1.0: return 2.7
    if change_since_signal < 2.0: return 1.3
    return 0.0
