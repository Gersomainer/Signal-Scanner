from __future__ import annotations
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Iterable
from .models import Company

CORP_SUFFIXES = {
    'inc','incorporated','corp','corporation','co','company','ltd','limited','plc','llc','lp','holdings','holding',
    'group','sa','ag','nv','se','spa','s.p.a','pte','technologies','technology'
}

@dataclass
class Resolution:
    query: str
    company: Company | None
    confidence: float
    method: str


def normalize_name(name: str) -> str:
    s = name.lower().replace('&', ' and ')
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    toks = [t for t in s.split() if t not in CORP_SUFFIXES]
    return ' '.join(toks)


class PublicCompanyResolver:
    """Conservative issuer-name -> listed-company resolver.

    Exact normalized matches are preferred. Fuzzy matches require a high threshold
    and token overlap to avoid mapping generic supplier names to the wrong issuer.
    """
    def __init__(self, companies: Iterable[Company]):
        self.companies = list(companies)
        self.by_norm: dict[str, list[Company]] = {}
        for c in self.companies:
            n = normalize_name(c.name)
            if n:
                self.by_norm.setdefault(n, []).append(c)

    def resolve(self, query: str, fuzzy_threshold: float = 0.91) -> Resolution:
        qn = normalize_name(query)
        if not qn:
            return Resolution(query, None, 0.0, 'empty')
        exact = self.by_norm.get(qn, [])
        if len(exact) == 1:
            return Resolution(query, exact[0], 1.0, 'exact')
        if len(exact) > 1:
            return Resolution(query, None, 0.0, 'ambiguous-exact')

        qtokens = set(qn.split())
        best: tuple[float, Company] | None = None
        for c in self.companies:
            cn = normalize_name(c.name)
            ctokens = set(cn.split())
            if not qtokens or not ctokens:
                continue
            overlap = len(qtokens & ctokens) / len(qtokens | ctokens)
            # Require meaningful token overlap in addition to edit similarity.
            if overlap < 0.5:
                continue
            sim = SequenceMatcher(None, qn, cn).ratio()
            score = 0.7 * sim + 0.3 * overlap
            if best is None or score > best[0]:
                best = (score, c)
        if best and best[0] >= fuzzy_threshold:
            return Resolution(query, best[1], round(best[0], 3), 'fuzzy')
        return Resolution(query, None, round(best[0], 3) if best else 0.0, 'unresolved')
