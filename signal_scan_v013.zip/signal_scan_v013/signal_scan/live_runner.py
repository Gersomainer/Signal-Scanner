from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from .config import SETTINGS
from .sec_client import SECClient
from .massive_client import MassiveClient
from .universe import sec_listed_universe, enrich_and_filter_massive
from .structural_pipeline import scan_customer_filings
from .forced_sources import federal_register_events, qualifying_events
from .beneficiary_resolution import resolve_event_beneficiaries


def write_csv(path: Path, rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('')
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description='Signal Scan V0.1.3 retrieval runner')
    ap.add_argument('--out', default='data/live_v013')
    ap.add_argument('--structural-limit', type=int, default=250, help='Number of downstream issuers for the first structural pass')
    ap.add_argument('--filings-per-company', type=int, default=3)
    ap.add_argument('--fedreg-days', type=int, default=120)
    ap.add_argument('--skip-market-cap', action='store_true', help='Use SEC universe without Massive market-cap filtering')
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)

    universe = sec_listed_universe()
    (out/'sec_universe_count.txt').write_text(str(len(universe)))

    if not args.skip_market_cap:
        massive = MassiveClient()
        investable = enrich_and_filter_massive(universe, massive, asof=SETTINGS.frozen_date)
    else:
        investable = universe

    # Engine A retrieval pass. For v0.1.3 we scan a deterministic slice; production
    # should prioritize likely downstream sectors and checkpoint through the full set.
    customers = investable[:args.structural_limit]
    sec = SECClient()
    structural, observations = scan_customer_filings(customers, sec, universe, args.filings_per_company)
    write_csv(out/'engine_a_structural_candidates.csv', [{
        'supplier_name': x.supplier_name, 'ticker': x.ticker or '', 'company_name': x.company_name or '',
        'independent_customers': x.independent_customers, 'engine_score': x.engine_score,
        'resolution_confidence': x.resolution_confidence, 'status': x.status,
    } for x in structural])
    write_csv(out/'engine_a_unresolved_dependencies.csv', [{
        'customer': o.customer, 'filing_date': o.filing_date, 'dependency_type': o.dependency_type,
        'supplier': o.supplier or '', 'source_url': o.source_url or '', 'context': o.context[:1000],
    } for o in observations if not o.supplier])

    # Engine C regulatory feed + beneficiary resolution.
    events = federal_register_events(days=args.fedreg_days, per_page=100)
    qevents = [e for e, r in qualifying_events(events)]
    beneficiaries = resolve_event_beneficiaries(qevents, universe)
    write_csv(out/'engine_c_events.csv', [{
        'title': e.title, 'publication_date': e.publication_date, 'effective_date': e.effective_date or '',
        'source_type': e.source_type, 'source_url': e.source_url or '',
    } for e in qevents])
    write_csv(out/'engine_c_beneficiaries.csv', [{
        'event_title': b.event_title, 'beneficiary_name': b.beneficiary_name,
        'ticker': b.ticker or '', 'company_name': b.company_name or '', 'engine_score': b.engine_score,
        'resolution_confidence': b.resolution_confidence, 'status': b.status, 'source_url': b.source_url or '',
    } for b in beneficiaries])

    manifest = {
        'version': '0.1.3', 'frozen_scoring_version': '0.1.2', 'freeze_date': SETTINGS.frozen_date,
        'sec_universe': len(universe), 'investable_universe': len(investable),
        'engine_a_customers_scanned': len(customers), 'engine_a_candidates': len(structural),
        'engine_c_events': len(qevents), 'engine_c_beneficiaries': len(beneficiaries),
    }
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2))
    print(json.dumps(manifest, indent=2))

if __name__ == '__main__':
    main()
