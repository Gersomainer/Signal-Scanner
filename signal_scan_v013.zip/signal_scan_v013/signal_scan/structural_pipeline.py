from __future__ import annotations
from dataclasses import dataclass, field
from .fragility import build_dependency_observations, cluster_by_supplier, DependencyObservation
from .entity_resolution import PublicCompanyResolver, Resolution
from .filings import recent_filing_records, filing_url, fetch_filing_text

@dataclass
class StructuralCandidate:
    supplier_name: str
    ticker: str | None
    company_name: str | None
    independent_customers: int
    engine_score: float
    resolution_confidence: float
    observations: list[DependencyObservation] = field(default_factory=list)
    status: str = 'UNRESOLVED'


def scan_customer_filings(customers, sec_client, public_universe, max_filings_per_company: int = 4):
    observations: list[DependencyObservation] = []
    for customer in customers:
        if not customer.cik:
            continue
        try:
            sub = sec_client.submissions(customer.cik)
        except Exception:
            continue
        for rec in recent_filing_records(sub, limit=max_filings_per_company):
            try:
                url = filing_url(customer.cik, rec['accession'], rec['primary_document'])
                text = fetch_filing_text(url)
                observations.extend(build_dependency_observations(customer.name, rec['filing_date'], text, url))
            except Exception:
                continue
    resolver = PublicCompanyResolver(public_universe)
    candidates = []
    for cluster in cluster_by_supplier(observations):
        res = resolver.resolve(cluster.key)
        candidates.append(StructuralCandidate(
            supplier_name=cluster.key,
            ticker=res.company.ticker if res.company else None,
            company_name=res.company.name if res.company else None,
            independent_customers=cluster.independent_customers,
            engine_score=cluster.engine_score,
            resolution_confidence=res.confidence,
            observations=cluster.observations,
            status='RESOLVED' if res.company else 'UNRESOLVED',
        ))
    return sorted(candidates, key=lambda x: (x.status == 'RESOLVED', x.engine_score, x.independent_customers), reverse=True), observations
