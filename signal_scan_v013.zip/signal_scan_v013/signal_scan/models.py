from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class Company:
    ticker: str
    name: str
    exchange: str = ""
    cik: Optional[str] = None
    market_cap: Optional[float] = None
    sector: str = ""
    industry: str = ""

@dataclass
class CandidateMetrics:
    concentration: float = 0
    nonlinearity: float = 0
    evidence: float = 0
    market_response: float = 0
    moat: float = 0
    survival: float = 0
    dilution: float = 0
    insider: float = 2.5

@dataclass
class SignalCard:
    company: Company
    engine: str
    signal: str
    first_detected_date: str
    engine_score: float
    metrics: CandidateMetrics
    key_risk: str = ""
    evidence_summary: str = ""
    discovery_state: str = "Unknown"
    total_score: float = 0
    classification: str = "WATCH"

    def to_dict(self):
        d = asdict(self)
        d["ticker"] = self.company.ticker
        d["company_name"] = self.company.name
        d["market_cap"] = self.company.market_cap
        return d
