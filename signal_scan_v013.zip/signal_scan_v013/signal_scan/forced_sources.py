from __future__ import annotations
import requests
from datetime import date, timedelta
from .forced_demand import ForcedDemandEvent, evaluate_event
from .regulatory import normalize_regulatory_document
from .procurement import normalize_ted_notice

FEDREG_API = 'https://www.federalregister.gov/api/v1/documents.json'
TED_API = 'https://api.ted.europa.eu/v3/notices/search'


def federal_register_events(days: int = 90, per_page: int = 100) -> list[ForcedDemandEvent]:
    end = date.today()
    start = end - timedelta(days=days)
    params = {
        'per_page': per_page,
        'order': 'newest',
        'conditions[publication_date][gte]': start.isoformat(),
        'conditions[publication_date][lte]': end.isoformat(),
        'conditions[type][]': 'RULE',
    }
    r = requests.get(FEDREG_API, params=params, timeout=30)
    r.raise_for_status()
    out = []
    for d in r.json().get('results', []):
        out.append(normalize_regulatory_document({
            'title': d.get('title',''),
            'publication_date': d.get('publication_date',''),
            'source_type': 'Federal Register',
            'abstract': d.get('abstract','') or '',
            'url': d.get('html_url'),
            'effective_date': d.get('effective_on'),
            'final_rule': True,
        }))
    return out


def ted_search_events(query: str, limit: int = 100) -> list[ForcedDemandEvent]:
    """Query TED Search API. Kept schema-tolerant because TED evolves fields."""
    payload = {
        'query': query,
        'fields': ['notice-title','publication-date','buyer-name','winner-name','short-description','html-url'],
        'limit': limit,
    }
    r = requests.post(TED_API, json=payload, timeout=40)
    r.raise_for_status()
    data = r.json()
    notices = data.get('notices') or data.get('results') or []
    return [normalize_ted_notice(n) for n in notices]


def qualifying_events(events: list[ForcedDemandEvent], min_score: float = 2.5):
    scored = [(e, evaluate_event(e)) for e in events]
    return sorted([(e,r) for e,r in scored if r.engine_score >= min_score], key=lambda x: x[1].engine_score, reverse=True)
