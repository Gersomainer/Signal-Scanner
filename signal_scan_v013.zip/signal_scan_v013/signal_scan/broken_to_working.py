from __future__ import annotations
from dataclasses import dataclass
from .xbrl import quarterly_values

@dataclass
class BTWResult:
    qualifies: bool
    engine_score: float
    reasons: list[str]
    metrics: dict

def pct_change(a, b):
    if a in (None, 0) or b is None: return None
    return (b - a) / abs(a)

def evaluate_companyfacts(companyfacts: dict) -> BTWResult:
    rev = quarterly_values(companyfacts, "revenue")
    gp = quarterly_values(companyfacts, "gross_profit")
    ocf = quarterly_values(companyfacts, "operating_cf")
    oi = quarterly_values(companyfacts, "operating_income")
    reasons, metrics = [], {}

    def last4(series): return series[-4:] if len(series) >= 4 else series
    r4, g4, c4, o4 = map(last4, (rev, gp, ocf, oi))

    improvements = 0
    if len(r4) >= 2:
        growth = pct_change(r4[-2]["val"], r4[-1]["val"])
        metrics["revenue_qoq"] = growth
        if growth is not None and growth >= 0.20:
            improvements += 1; reasons.append(f"Revenue grew {growth:.0%} sequentially")

    if len(g4) >= 2:
        if g4[-2]["val"] <= 0 < g4[-1]["val"]:
            improvements += 2; reasons.append("Gross profit crossed positive")
        elif g4[-1]["val"] > g4[-2]["val"]:
            improvements += 1; reasons.append("Gross profit improved")

    if len(o4) >= 2 and o4[-1]["val"] > o4[-2]["val"]:
        improvements += 1; reasons.append("Operating income/loss improved")

    if len(c4) >= 2:
        # For negative OCF, moving toward zero is improvement.
        prev, cur = c4[-2]["val"], c4[-1]["val"]
        if cur > prev:
            improvements += 1; reasons.append("Operating cash flow improved")

    score = min(5.0, improvements * 0.9)
    return BTWResult(improvements >= 2, round(score, 1), reasons, metrics)
