from __future__ import annotations
from .models import Company, CandidateMetrics, SignalCard
from .scoring import finalize
from .fragility import FragilityCluster
from .forced_demand import ForcedDemandResult, ForcedDemandEvent


def structural_fragility_card(company: Company, cluster: FragilityCluster, freeze_date: str,
                               concentration_score: float, nonlinearity_score: float,
                               evidence_score: float, market_response_score: float,
                               moat_score: float, survival_score: float,
                               dilution_score: float, insider_score: float = 2.5):
    card = SignalCard(
        company=company,
        engine="Structural Fragility",
        signal=f"{cluster.independent_customers} independent customer(s) disclose dependency on {cluster.key}",
        first_detected_date=freeze_date,
        engine_score=cluster.engine_score,
        metrics=CandidateMetrics(
            concentration=concentration_score,
            nonlinearity=nonlinearity_score,
            evidence=evidence_score,
            market_response=market_response_score,
            moat=moat_score,
            survival=survival_score,
            dilution=dilution_score,
            insider=insider_score,
        ),
        key_risk="Dependency may be real but economically immaterial to the supplier, or customers may qualify substitutes.",
        evidence_summary=" | ".join(o.context[:220] for o in cluster.observations[:3]),
        discovery_state="Unknown",
    )
    return finalize(card)


def forced_demand_card(company: Company, event: ForcedDemandEvent, result: ForcedDemandResult, freeze_date: str,
                       concentration_score: float, nonlinearity_score: float,
                       evidence_score: float, market_response_score: float,
                       moat_score: float, survival_score: float,
                       dilution_score: float, insider_score: float = 2.5):
    card = SignalCard(
        company=company,
        engine="Forced Demand",
        signal=f"{event.title}: " + "; ".join(result.reasons),
        first_detected_date=freeze_date,
        engine_score=result.engine_score,
        metrics=CandidateMetrics(
            concentration=concentration_score,
            nonlinearity=nonlinearity_score,
            evidence=evidence_score,
            market_response=market_response_score,
            moat=moat_score,
            survival=survival_score,
            dilution=dilution_score,
            insider=insider_score,
        ),
        key_risk="Mandate timing, enforcement, budget, or supplier eligibility may change before revenue is realized.",
        evidence_summary=event.text[:700],
        discovery_state="Unknown",
    )
    return finalize(card)
