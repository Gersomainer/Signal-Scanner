"""Generic regulatory-event normalization for Forced Demand.

Specific Federal Register / agency / standards-body clients can feed this
normalizer. Keeping normalization generic prevents source-specific wording from
leaking into the scoring model.
"""
from __future__ import annotations
from .forced_demand import ForcedDemandEvent


def normalize_regulatory_document(doc: dict) -> ForcedDemandEvent:
    return ForcedDemandEvent(
        title=doc.get("title", "Regulatory document"),
        publication_date=str(doc.get("publication_date") or "")[:10],
        source_type=doc.get("source_type", "Regulator"),
        text="\n".join([doc.get("title", ""), doc.get("abstract", ""), doc.get("text", "")]),
        source_url=doc.get("url"),
        effective_date=(str(doc.get("effective_date") or "")[:10] or None),
        final_rule=bool(doc.get("final_rule", False)),
        supplier_pool_size=doc.get("supplier_pool_size"),
        named_beneficiaries=list(doc.get("named_beneficiaries") or []),
    )
