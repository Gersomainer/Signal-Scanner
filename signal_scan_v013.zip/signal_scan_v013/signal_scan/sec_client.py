from __future__ import annotations
import time
import requests
from .config import SETTINGS

class SECClient:
    def __init__(self, user_agent: str | None = None, min_interval: float = 0.12):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": user_agent or SETTINGS.sec_user_agent,
            "Accept-Encoding": "gzip, deflate",
        })
        self.min_interval = min_interval
        self._last = 0.0

    def _get_json(self, url: str):
        elapsed = time.time() - self._last
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        r = self.session.get(url, timeout=30)
        self._last = time.time()
        r.raise_for_status()
        return r.json()

    @staticmethod
    def cik10(cik: str | int) -> str:
        return str(cik).replace("CIK", "").zfill(10)

    def submissions(self, cik: str | int):
        return self._get_json(f"https://data.sec.gov/submissions/CIK{self.cik10(cik)}.json")

    def companyfacts(self, cik: str | int):
        return self._get_json(f"https://data.sec.gov/api/xbrl/companyfacts/CIK{self.cik10(cik)}.json")
