from __future__ import annotations
import requests
from .models import Company
from .config import SETTINGS

SEC_TICKERS_URL = 'https://www.sec.gov/files/company_tickers_exchange.json'


def sec_listed_universe(user_agent: str | None = None) -> list[Company]:
    """Fetch SEC's ticker/exchange mapping. No market-cap filtering here."""
    headers = {'User-Agent': user_agent or SETTINGS.sec_user_agent}
    r = requests.get(SEC_TICKERS_URL, headers=headers, timeout=30)
    r.raise_for_status()
    payload = r.json()
    fields = payload['fields']
    out = []
    for row in payload['data']:
        x = dict(zip(fields, row))
        ticker = str(x.get('ticker') or '').strip()
        if not ticker:
            continue
        out.append(Company(
            ticker=ticker,
            name=str(x.get('name') or ''),
            exchange=str(x.get('exchange') or ''),
            cik=str(x.get('cik') or ''),
        ))
    return out


def enrich_and_filter_massive(companies: list[Company], massive_client, asof: str | None = None,
                               min_cap: float = SETTINGS.min_market_cap,
                               max_cap: float = SETTINGS.max_market_cap) -> list[Company]:
    """Market-cap enrich SEC universe through Massive and keep discovery range.

    Designed for paged/batched callers; free Massive rate limits make a complete
    first run slow, but this remains deterministic and resumable at a higher layer.
    """
    out = []
    for c in companies:
        try:
            raw = massive_client.ticker_details(c.ticker, asof)
            result = raw.get('results') or {}
            mc = result.get('market_cap')
            if mc is None or not (min_cap <= float(mc) <= max_cap):
                continue
            c.market_cap = float(mc)
            c.sector = str(result.get('sic_description') or '')
            out.append(c)
        except Exception:
            continue
    return out
