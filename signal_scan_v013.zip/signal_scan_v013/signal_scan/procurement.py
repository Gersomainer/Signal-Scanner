"""Procurement-source adapters for Forced Demand.

V0.1.2 deliberately separates source retrieval from event scoring. SAM.gov and
TED payloads can be normalized here without coupling the engine to one API.
"""
from __future__ import annotations
from .forced_demand import ForcedDemandEvent


def normalize_sam_notice(notice: dict) -> ForcedDemandEvent:
    title = notice.get("title") or notice.get("subject") or "SAM.gov notice"
    text_parts = [title, notice.get("description") or "", notice.get("additionalInfo") or ""]
    notice_type = str(notice.get("type") or notice.get("typeOfSetAsideDescription") or "")
    if "sole" in notice_type.lower():
        text_parts.append("sole source")
    return ForcedDemandEvent(
        title=title,
        publication_date=str(notice.get("postedDate") or notice.get("publishDate") or "")[:10],
        source_type="SAM.gov",
        text="\n".join(text_parts),
        source_url=notice.get("uiLink") or notice.get("url"),
        effective_date=(str(notice.get("responseDeadLine") or "")[:10] or None),
        final_rule=False,
        named_beneficiaries=[x for x in [notice.get("awardee", {}).get("name") if isinstance(notice.get("awardee"), dict) else None] if x],
    )


def normalize_ted_notice(notice: dict) -> ForcedDemandEvent:
    # TED field selection is configurable; accept common flattened field names.
    title = notice.get("title") or notice.get("notice-title") or "TED notice"
    description = notice.get("description") or notice.get("short-description") or ""
    return ForcedDemandEvent(
        title=str(title),
        publication_date=str(notice.get("publication-date") or notice.get("publicationDate") or "")[:10],
        source_type="TED",
        text=f"{title}\n{description}",
        source_url=notice.get("url") or notice.get("html-url"),
        effective_date=(str(notice.get("deadline") or notice.get("contract-duration-end") or "")[:10] or None),
        final_rule=False,
    )
