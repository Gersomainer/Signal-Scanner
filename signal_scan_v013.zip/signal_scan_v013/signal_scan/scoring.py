from __future__ import annotations
from .models import CandidateMetrics, SignalCard

BASE_WEIGHTS = {
    "concentration": 20,
    "nonlinearity": 20,
    "evidence": 15,
    "market_response": 15,
    "moat": 10,
    "survival": 10,
    "dilution": 5,
    "insider": 5,
}

# Engine-specific interpretation. Same 100-point envelope, different economic meaning.
ENGINE_WEIGHTS = {
    "Structural Fragility": BASE_WEIGHTS,
    "Forced Demand": BASE_WEIGHTS,
    # For distressed turnarounds, 'concentration' is replaced by operating-inflection breadth:
    # how much of consolidated economics is touched by the improving KPIs.
    "Broken-to-Working": {
        "concentration": 15,
        "nonlinearity": 25,
        "evidence": 15,
        "market_response": 15,
        "moat": 5,
        "survival": 15,
        "dilution": 7.5,
        "insider": 2.5,
    },
}


def weights_for(engine: str | None = None):
    return ENGINE_WEIGHTS.get(engine or "", BASE_WEIGHTS)


def score(metrics: CandidateMetrics, engine: str | None = None) -> float:
    vals = vars(metrics)
    weights = weights_for(engine)
    total = 0.0
    for k, weight in weights.items():
        v = max(0.0, min(5.0, float(vals[k])))
        total += (v / 5.0) * weight
    return round(total, 1)


def classify(total: float) -> str:
    if total >= 85: return "EXCEPTIONAL"
    if total >= 75: return "HIGH PRIORITY"
    if total >= 65: return "INVESTIGATE"
    if total >= 50: return "WATCH"
    return "IGNORE"


def finalize(card: SignalCard) -> SignalCard:
    card.total_score = score(card.metrics, card.engine)
    card.classification = classify(card.total_score)
    return card
